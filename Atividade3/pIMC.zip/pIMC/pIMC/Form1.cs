﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pIMC
{
    public partial class Form1 : Form
    {
        double altura, peso, imc;

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso))

                MessageBox.Show("Peso Inválido!");
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso.Text = "";
            txtIMC.Text = "";
        }

        private void BntCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))

                MessageBox.Show("Altura Inválida!");
            else
                if (!double.TryParse(txtPeso.Text, out peso))

                MessageBox.Show("Peso Inválido!");
            else
            {
                imc = peso / (altura * altura);
                    txtIMC.Text = imc.ToString();   
            }
            if (imc < 18.5)
            {
                txtCategoria.Text = "Abaixo do peso";
            }
            else
                if (imc < 24.9)
            {
                txtCategoria.Text = "Peso Normal";
            }
            else
                if (imc < 29.9)
            {
                txtCategoria.Text = "Sobrepeso";
            }
            else
                if (imc < 34.9)
            {
                txtCategoria.Text = "Obesidade grau I";
            }
            else
                if (imc < 39.9)
            {
                txtCategoria.Text = "Obesidade grau II";
            }
            else
                txtCategoria.Text = "Obesidade grau III";
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))

                MessageBox.Show("Altura Inválida!");
        }
    }
}
