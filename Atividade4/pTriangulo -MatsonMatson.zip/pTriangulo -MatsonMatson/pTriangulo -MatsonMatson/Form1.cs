﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTriangulo__MatsonMatson
{
    public partial class Form1 : Form
    {
        double txtA, txtB, txtC;

        public Form1()
        {
            InitializeComponent();
        }

              private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out txtA))
            {
                MessageBox.Show("Número Inválido");
          
            }
        }

              private void txtLadoB_Validated(object sender, EventArgs e)
              {
                  if(!double.TryParse(txtLadoB.Text, out txtB))
                      MessageBox.Show("Número Inválido");
                  
              }

              private void txtLadoC_Validated(object sender, EventArgs e)
              {
                  if (!double.TryParse(txtLadoC.Text, out txtB))
                      MessageBox.Show("Número Inválido");
                  
              }

              private void BntVerificar_Click(object sender, EventArgs e)
              {
                  if(!double.TryParse(txtLadoA.Text, out txtA))
                      MessageBox.Show("Número Inválido");

                  else if (!double.TryParse(txtLadoB.Text, out txtB))
                      MessageBox.Show("Número Inválido");

                  else if (!double.TryParse(txtLadoC.Text, out txtC))
                      MessageBox.Show("Número Inválido");
                  else
                  {
                      if ((txtA < (txtB + txtC)) &&
                          (txtA > Math.Abs(txtB - txtC)) &&
                          (txtB < (txtA + txtC)) &&
                          (txtB > Math.Abs(txtA - txtC)) &&
                          (txtC < (txtA + txtB)) &&
                          (txtC > Math.Abs(txtA - txtB))) 

                          if ((txtA == txtB) && (txtB == txtC))
                              MessageBox.Show("Equilátero");
                          else 
                              if ((txtA == txtB) || (txtA == txtC) || (txtB == txtC))
                                  MessageBox.Show("Isósceles");
                              else
                                  MessageBox.Show("Escaleno");
                  }
              }

              private void BntSair_Click(object sender, EventArgs e)
              {
                  Close();
              }

              private void BntLimpar_Click(object sender, EventArgs e)
              {
                  txtLadoA.Clear();
                  txtLadoB.Clear();
                  txtLadoC.Clear();
              }

    }
}
