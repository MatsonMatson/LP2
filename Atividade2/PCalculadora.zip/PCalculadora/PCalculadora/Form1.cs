﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; // Globais
      
        public Form1()
        {
            InitializeComponent();

        }
        private void BntLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtNum3.Text = "";

            txtNum1.Focus();
        }
        

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("Numero 2 Iválido!");
                // txtNum2.Focus();
            }


        }

        private void BntMult_Click(object sender, EventArgs e)
        {

            if (double.TryParse(txtNum1.Text, out numero1) &&
                double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                txtNum3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números Inválidos!");
        }

        private void BntDiv_Click(object sender, EventArgs e)
        {

            if (double.TryParse(txtNum1.Text, out numero1) &&
                double.TryParse(txtNum2.Text, out numero2))
            {
                if (numero2 == 0)
                    MessageBox.Show("Não pode dividir por Zero!!");
                else
                {
                    resultado = numero1 / numero2;
                    txtNum3.Text = resultado.ToString();
                }
            }
            else
                MessageBox.Show("Números Inválidos!");
        }

        private void BntSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BntAdd_Click(object sender, EventArgs e)
        {
            //   txtNum3.Text = txtNum1.Text + txtNum2.Text;

            if ((double.TryParse(txtNum1.Text, out numero1)) &&
                double.TryParse(txtNum2.Text, out numero2))

            {
                resultado = numero1 + numero2;
                txtNum3.Text = resultado.ToString();

                // BtnLimpar_Click(sender, e); // AQUI
            }
            else
                MessageBox.Show("Números Inválidos!");
        }

        private void BntSub_Click_1(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out numero1) &&
                double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                txtNum3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números Inválidos!");
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            // if ((txtNum1.Text=="") && (txtNum2.Text=="")) 

            if (!Double.TryParse(txtNum1.Text, out numero1))
            {
                MessageBox.Show("Número 1 Inválido!");
                // txtNum1.Focus();
            }
        }
    } 
}
