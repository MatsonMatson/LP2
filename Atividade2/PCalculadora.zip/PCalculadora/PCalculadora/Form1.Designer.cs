﻿namespace PCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.BntLimpar = new System.Windows.Forms.Button();
            this.BntSair = new System.Windows.Forms.Button();
            this.BntAdd = new System.Windows.Forms.Button();
            this.BntSub = new System.Windows.Forms.Button();
            this.BntMult = new System.Windows.Forms.Button();
            this.BntDiv = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(159, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(159, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Número 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(159, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Resultado";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(266, 76);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(168, 29);
            this.txtNum1.TabIndex = 3;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(266, 122);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(168, 29);
            this.txtNum2.TabIndex = 4;
            this.txtNum2.Validated += new System.EventHandler(this.txtNum2_Validated);
            // 
            // txtNum3
            // 
            this.txtNum3.Location = new System.Drawing.Point(266, 166);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(168, 29);
            this.txtNum3.TabIndex = 5;
            // 
            // BntLimpar
            // 
            this.BntLimpar.Location = new System.Drawing.Point(506, 76);
            this.BntLimpar.Name = "BntLimpar";
            this.BntLimpar.Size = new System.Drawing.Size(95, 39);
            this.BntLimpar.TabIndex = 6;
            this.BntLimpar.Text = "Limpar";
            this.BntLimpar.UseVisualStyleBackColor = true;
            this.BntLimpar.Click += new System.EventHandler(this.BntLimpar_Click);
            // 
            // BntSair
            // 
            this.BntSair.Location = new System.Drawing.Point(506, 135);
            this.BntSair.Name = "BntSair";
            this.BntSair.Size = new System.Drawing.Size(95, 38);
            this.BntSair.TabIndex = 7;
            this.BntSair.Text = "Sair";
            this.BntSair.UseVisualStyleBackColor = true;
            this.BntSair.Click += new System.EventHandler(this.BntSair_Click);
            // 
            // BntAdd
            // 
            this.BntAdd.Location = new System.Drawing.Point(199, 251);
            this.BntAdd.Name = "BntAdd";
            this.BntAdd.Size = new System.Drawing.Size(87, 50);
            this.BntAdd.TabIndex = 8;
            this.BntAdd.Text = "+";
            this.BntAdd.UseVisualStyleBackColor = true;
            this.BntAdd.Click += new System.EventHandler(this.BntAdd_Click);
            // 
            // BntSub
            // 
            this.BntSub.Location = new System.Drawing.Point(333, 251);
            this.BntSub.Name = "BntSub";
            this.BntSub.Size = new System.Drawing.Size(87, 50);
            this.BntSub.TabIndex = 9;
            this.BntSub.Text = "-";
            this.BntSub.UseVisualStyleBackColor = true;
            this.BntSub.Click += new System.EventHandler(this.BntSub_Click_1);
            // 
            // BntMult
            // 
            this.BntMult.Location = new System.Drawing.Point(469, 251);
            this.BntMult.Name = "BntMult";
            this.BntMult.Size = new System.Drawing.Size(88, 50);
            this.BntMult.TabIndex = 10;
            this.BntMult.Text = "*";
            this.BntMult.UseVisualStyleBackColor = true;
            this.BntMult.Click += new System.EventHandler(this.BntMult_Click);
            // 
            // BntDiv
            // 
            this.BntDiv.Location = new System.Drawing.Point(597, 251);
            this.BntDiv.Name = "BntDiv";
            this.BntDiv.Size = new System.Drawing.Size(88, 50);
            this.BntDiv.TabIndex = 11;
            this.BntDiv.Text = "/";
            this.BntDiv.UseVisualStyleBackColor = true;
            this.BntDiv.Click += new System.EventHandler(this.BntDiv_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1467, 762);
            this.Controls.Add(this.BntDiv);
            this.Controls.Add(this.BntMult);
            this.Controls.Add(this.BntSub);
            this.Controls.Add(this.BntAdd);
            this.Controls.Add(this.BntSair);
            this.Controls.Add(this.BntLimpar);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Button BntLimpar;
        private System.Windows.Forms.Button BntSair;
        private System.Windows.Forms.Button BntAdd;
        private System.Windows.Forms.Button BntSub;
        private System.Windows.Forms.Button BntMult;
        private System.Windows.Forms.Button BntDiv;
    }
}

